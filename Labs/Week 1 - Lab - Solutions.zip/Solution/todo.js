/**
 * To-Do List App Lab Instructions
 * --------------------------------
 *
 * Goal: Your task is to replicate the functionality of the provided example.
 * Example Link: https://65a047f8c51a3b297fcdba3f--cerulean-mousse-4a9723.netlify.app/
 *
 * Key Functions to Implement:
 * 1. Add a task to the list.
 * 2. Increment the task counter upon adding a task.
 * 3. Reset the list of tasks.
 * 4. Reset the task counter.
 *
 * Note: You may need to understand and use 'parseInt' to complete this lab.
 *       You can search online to learn how it works.
 *
 * Lab Bonus:
 * - Add validation to prevent adding an empty task.
 * - Allow adding a task by pressing the 'Enter' key.
 *
 * Good luck!
 */

function addTask() {
  const taskInput = document.getElementById("new-task");
  const taskList = document.getElementById("task-list");
  const taskText = taskInput.value;
  taskList.innerHTML += "<li>" + taskText + "</li>";
  updateTaskCounter();
  taskInput.value = "";
}

function clearTasks() {
  document.getElementById("task-list").innerHTML = "";
  document.getElementById("task-counter").innerHTML = "0";
}

function updateTaskCounter() {
  const taskCounter = document.getElementById("task-counter");
  let count = parseInt(taskCounter.innerHTML);
  taskCounter.innerHTML = count + 1;
}
